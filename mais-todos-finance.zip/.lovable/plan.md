## Objetivo
Importar em lote o histórico de parcelas pagas (7.334 registros) para `operacoes_parcelas_manuais`, sobrescrevendo sempre.

## 1. Edge function `bulk-import-parcelas`
`supabase/functions/bulk-import-parcelas/index.ts`

- CORS via `import { corsHeaders } from "npm:@supabase/supabase-js@2/cors"` (mesmo padrão de `reconcile-operacoes`).
- Valida JWT do chamador com cliente anon + `getUser()`, depois `has_role(user.id, 'admin')` com o cliente service role. Sem admin → 403.
- Body: `{ records: ParcelaRow[], mode: "upsert_all" }`. Valida cada record: `cnpj` (14 dígitos, normalizado), `month` (int ≥ 1), `actual_payment` (número). Registros inválidos vão para `errors[]` e são pulados.
- Detalhe técnico importante: o índice único é **expressão** (`COALESCE(id_valora,'')`, `COALESCE(seu_numero,'')`), então o `upsert`/`onConflict` do PostgREST não consegue mirá-lo. A função faz **DELETE das chaves do lote e depois INSERT** — idempotente e equivalente ao upsert.
  - DELETE em sub-lotes usando filtro `or(...)` por `(cnpj, id_valora, seu_numero, month)`, seguido de um `insert` único do lote.
- Processa em blocos de 500 dentro da requisição, `note` forçado para `"importado_planilha"`, `created_by` = usuário admin.
- Retorna `{ ok, inserted, updated, errors }` (`updated` = quantos já existiam e foram sobrescritos, contado pelas linhas deletadas).

## 2. Tela `/admin/importar-parcelas`
Nova página `src/pages/AdminImportarParcelas.tsx`, lazy-loaded, rota protegida com `<ProtectedRoute requireAdmin>` em `src/App.tsx`.

- Título "Importar Histórico de Parcelas Pagas" + descrição sobre sobrescrita.
- Input `accept=".json"`; ao selecionar: parse, valida array e campos obrigatórios, mostra total de registros e amostra das 3 primeiras linhas em tabela.
- Botão "Importar" desabilitado até haver arquivo válido.
- Envia em chunks de 500 via `supabase.functions.invoke("bulk-import-parcelas", ...)`, sequencialmente, com barra de progresso ("Enviando lote X de Y…") usando o `Progress` do shadcn.
- Ao final: toast de sucesso com totais, ou card com a lista de erros agregados.
- Só tokens semânticos (`bg-primary`, `text-muted-foreground` etc.).

## 3. Navegação
Botão/link "Importar Parcelas" no cabeçalho de `/admin/limites` (visível apenas para admin, que já é a condição da rota), navegando para `/admin/importar-parcelas`.

## Invariantes
- Nenhuma migração; tabela, RLS e `useParcelasManuais` intactos.
- Nenhuma outra edge function ou tabela alterada.
- Import idempotente; `note = "importado_planilha"` em todos os registros.
